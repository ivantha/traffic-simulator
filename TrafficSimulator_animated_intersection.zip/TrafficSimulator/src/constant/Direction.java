package constant;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}
