package constant;

public enum LaneType {
    IN_LANE,
    OUT_LANE,
    INTERSECTION_LANE
}
