package com.ivantha.ts.constant;

public enum LaneType {
    IN_LANE,
    OUT_LANE,
    INTERSECTION_LANE
}
