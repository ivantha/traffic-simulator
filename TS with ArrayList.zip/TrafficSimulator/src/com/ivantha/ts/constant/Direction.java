package com.ivantha.ts.constant;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}
