package com.ivantha.ts.constant;

public enum State {
    ON_IN_LANE,
    ON_OUT_LANE,
    ON_INTERSECTION
}
