Movsim Misc Directory
=====================

MovSim = **M**ulti-model **o**pen-source **v**ehicular-traffic **Sim**ulator.

http://www.movsim.org


Description
-----------

The `misc/` directory contains miscellaneous resources, e.g. some codestyle resources in `codestyle/`


Commercial use
--------------

For commercial use, please contact the copyright holders at movsim@akesting.de


Copyright
---------

MovSim is Copyright (C) 2010-2016 by Arne Kesting, Martin Treiber, Ralph Germ, and Martin Budden.

MovSim is licensed under [GPL version 3](https://github.com/movsim/movsim/blob/develop/COPYING).

