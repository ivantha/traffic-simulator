package model;

public enum LaneType {
    IN_LANE,
    OUT_LANE
}
